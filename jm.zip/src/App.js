import "bootstrap/dist/css/bootstrap.min.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./App.css";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Control from "./components/Control";
import Footer from "./components/Footer";
import Faq from "./components/Faq";
import YouGo from "./components/YouGo";
import Product from "./assets/img/svg/Product";
import Esim from "./components/Esim";

function App() {
  return (
    <div className="bg-black overflow-hidden">
      <Header />
      <Hero />
      <Control />
      <Esim />
      <Product />
      <YouGo />
      <Faq />
      <Footer />
    </div>
  );
}

export default App;
